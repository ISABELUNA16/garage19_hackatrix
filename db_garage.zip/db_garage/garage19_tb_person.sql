CREATE DATABASE  IF NOT EXISTS `garage19` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `garage19`;
-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: garage19
-- ------------------------------------------------------
-- Server version	5.5.62

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_person`
--

DROP TABLE IF EXISTS `tb_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tb_person` (
  `id_person` int(11) NOT NULL AUTO_INCREMENT,
  `id_group` int(11) NOT NULL,
  `firstname_person` varchar(255) NOT NULL,
  `lastname_person` varchar(255) NOT NULL,
  `date_birth` date DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `province` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `country` varchar(250) NOT NULL,
  `criminal_record` varchar(250) NOT NULL,
  `description` text,
  `start_register` date DEFAULT NULL,
  `id_area` int(11) NOT NULL,
  PRIMARY KEY (`id_person`),
  KEY `id_group` (`id_group`),
  CONSTRAINT `tb_person_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `tb_group` (`id_group`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_person`
--

LOCK TABLES `tb_person` WRITE;
/*!40000 ALTER TABLE `tb_person` DISABLE KEYS */;
INSERT INTO `tb_person` VALUES (1,1,'Luis','Castillo','1990-01-01','Av los conquistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedor','2019-06-01',1),(2,1,'Roberto','Hidalgo','1990-01-01','Av los conquistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedor','2019-06-01',1),(3,1,'Gina','Luna','1990-01-01','Av los conquostadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedora','2019-06-01',1),(4,1,'Rosmery','Luna','1990-01-01','Av los conquistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedora','2019-06-01',1),(5,1,'Briham','B','1990-01-01','Av los conquistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedora','2019-06-01',1),(6,1,'Erika','Vidal','1990-01-01','Av los conquistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedor','2019-06-01',1),(7,1,'José ','Salas','1990-01-01','Av los conuistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedor','2019-06-01',1),(8,1,'ALmendra','Cornejo','1990-01-01','Av los conquistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedor','2019-06-01',1),(9,1,'Emel','Helmut','1990-01-01','Av los conquistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprendedor','2019-06-01',1),(10,1,'Jorge','Villar','1990-01-01','Av los conquistadores','Lima','San Juan de Lurigancho','Peru','NO','Emprenderdor','2019-06-01',1);
/*!40000 ALTER TABLE `tb_person` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-01 15:50:31
